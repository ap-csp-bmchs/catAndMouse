import pygame
pygame.init

#create game area
arena = pygame.display.set_mode((600, 600))
arena.fill((0, 0, 0))
pygame.display.update()
pygame.display.set_caption("Trick Or Treat")
clock = pygame.time.Clock()

#create cat and mouse
char = pygame.sprite.Group
town = pygame.image.load('town.png')
trick = pygame.image.load('trick.png')
pygame.display.update()
def trick_m(x,y):
    arena.blit(trick, (x,y))
t_x = (250)
t_y = (250)

#game loop
while True:

    # quit on x
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()

    #update character position
    arena.blit(town, (0,0))
    trick_m(t_x,t_y)
    pygame.display.update()

    # check for move of player
    if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                t_x = t_x - 2
    if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                t_x = t_x + 2
    if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                if t_y >= 88:
                    print (t_y)
                    t_y = t_y - 2
    if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                if t_y + 50 <= 470:
                    t_y = t_y + 2
    #mouse pathfinding

