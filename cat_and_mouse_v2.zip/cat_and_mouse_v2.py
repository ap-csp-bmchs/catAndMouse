import pygame
pygame.init

#create game area
arena = pygame.display.set_mode((1000, 700))
arena.fill((0, 0, 0))
pygame.display.update()
pygame.display.set_caption("Trick Or Treat")

#create cat and mouse
char = pygame.sprite.Group
trick = pygame.image.load('testp.png')
town = pygame.image.load('testp.png')
arena.blit(town, (0,0))
pygame.display.update()

#game loop
while True:

    # quit on x
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()

    # check for move of player

    #mouse pathfinding

    

