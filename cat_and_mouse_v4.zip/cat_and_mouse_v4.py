import pygame
pygame.init

#create game area
arena = pygame.display.set_mode((600, 600))
arena.fill((0, 0, 0))
pygame.display.update()
pygame.display.set_caption("Trick Or Treat")
clock = pygame.time.Clock()

#create cat and mouse
char = pygame.sprite.Group
town = pygame.image.load('town.png')
trick = pygame.image.load('trick.png')
treat = pygame.image.load('treat.png')
pygame.display.update()
def trick_m(x,y):
    arena.blit(trick, (x,y))
def treat_m(x,y):
    arena.blit(treat, (x,y))
t_x = (250)
t_y = (250)
tt_x = (400)
tt_y = (100)

#game loop
while True:

    # quit on x
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()

    #update character position
    arena.blit(town, (0,0))
    treat_m(tt_x,tt_y)
    trick_m(t_x,t_y)
    pygame.display.update()

    # check for move of player
    if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                if t_x - 50 > 16:
                    t_x = t_x - 2
    if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                if t_x + 50 < 486:
                    t_x = t_x + 2
    if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                if t_y >= 88:
                    t_y = t_y - 2
    if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                if t_y + 50 <= 470:
                    t_y = t_y + 2
    #check for cat and mouse collision
    if t_x < tt_x + 100 and t_x > tt_x:
        if t_y > tt_y and t_y <  tt_y + 100:
            tt_y = (250)
            tt_x = (250)
    if t_x + 100 < tt_x + 100 and t_x + 100 > tt_x:
        if t_y > tt_y and t_y <  tt_y + 100:
            tt_y = (250)
            tt_x = (250)
    if t_x < tt_x + 100 and t_x > tt_x:
        if t_y + 100 > tt_y and t_y + 100 <  tt_y + 100:
            tt_y = (250)
            tt_x = (250)
    if t_x + 100 < tt_x + 100 and t_x + 100 > tt_x:
        if t_y + 100 > tt_y and t_y + 100 <  tt_y + 100:
            tt_y = (250)
            tt_x = (250)
    #mouse pathfinding

